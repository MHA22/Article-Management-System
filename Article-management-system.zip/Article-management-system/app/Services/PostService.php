<?php

namespace App\Services;

use App\Models\Post;
use App\Models\Tag;
use Illuminate\Support\Facades\Cache;

class PostService
{
    public function getAllPosts()
    {
        $ttl = now()->addMinutes(env('POST_CACHE_TTL', 10));
        $posts = Cache::remember('posts_with_details', $ttl, function () {
            return Post::with([
                'user',
                'comments',
                'tags',
            ])->get();
        });

        return $posts;
    }

    /**
     * @param array $data
     *
     * کش ها به صورت اتوماتیک با استفاده از event , listener و مدل بروز رسانی میشوند
     *
     * @return Post
     */
    public function storePost(array $data): Post
    {
        $data['user_id'] = auth()->id();
        $post = Post::create($data);

        if (!empty($data['tags'])) {
            $post->tags()->sync($data['tags']);
        }

        return $post;
    }


    public function findPostById(int $id)
    {
        return Post::with('user', 'comments', 'tags')->find($id) ?? [404 , 'رکورد فوق یافت نشد!'];
    }

    /**
     * @param Post $post
     *
     *  کش ها به صورت اتوماتیک با استفاده از event , listener و مدل بروز رسانی میشوند
     *
     * @param array $data
     * @return Post
     */
    public function updatePost(Post $post, array $data): Post
    {
        $post->update($data);

        if (!empty($data['tags'])) {
            $post->tags()->sync($data['tags']);
        }

        return $post;
    }

    /**
     * @param Post $post
     *
     *  کش ها به صورت اتوماتیک با استفاده از event , listener و مدل بروز رسانی میشوند
     *
     * @return void
     */
    public function deletePost(Post $post)
    {
        $post->delete();
    }
}

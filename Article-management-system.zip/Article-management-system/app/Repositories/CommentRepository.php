<?php

namespace App\Repositories;

use App\Models\Comment;
use Illuminate\Support\Facades\DB;

class CommentRepository
{
    protected $model;

    public function __construct(Comment $model)
    {
        $this->model = $model;
    }

    public function storeComment(array $data, $commentable)
    {
        $comment = new Comment($data);
        $comment->commentable()->associate($commentable);
        $comment->save();

        return $comment;
    }


    public function getCommentsForCommentable($commentable)
    {
        return $commentable->comments()->get();
    }
}

<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\PostRequest;
use App\Http\Resources\PostResource;
use App\Repositories\PostRepository;
use App\Services\PostService;
use Illuminate\Http\Request;

class PostController extends Controller
{
    protected $postService;

    public function __construct(PostService $postService)
    {
        $this->postService = $postService;
    }

    /**
     * Get all posts.
     */
    public function index()
    {
        $posts = $this->postService->getAllPosts();
        return PostResource::collection($posts);
    }

    /**
     * Store a new post.
     */
    public function store(PostRequest $request)
    {
        $post = $this->postService->storePost($request->validated());
        return new PostResource($post);
    }

    /**
     * Show a specific post.
     */
    public function show($id)
    {
        $post = $this->postService->findPostById($id);
        return new PostResource($post);
    }

    /**
     * Update an existing post.
     */
    public function update(PostRequest $request, $id)
    {
        $post = $this->postService->findPostById($id);
        $updatedPost = $this->postService->updatePost($post, $request->validated());
        return new PostResource($updatedPost);
    }

    /**
     * Delete a post.
     */
    public function destroy($id)
    {
        $post = $this->postService->findPostById($id);
        if ($post[0] == 404){
            return  response()->json(['message' => $post[1]], $post[0]);
        }
        $this->postService->deletePost($post);
        return response()->json(['message' => 'عملیات با موفقیت انجام شد.'], 200);
    }
}

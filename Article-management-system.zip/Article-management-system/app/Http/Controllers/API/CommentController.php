<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\CommentRequest;
use App\Http\Resources\CommentResource;
use App\Models\Post;
use App\Models\User;
use App\Repositories\CommentRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class CommentController extends Controller
{
    protected $commentRepository;

    public function __construct(CommentRepository $commentRepository)
    {
        $this->commentRepository = $commentRepository;
    }

    /**
     * Store a new comment on a commentable entity (post or user).
     */
    public function store(CommentRequest $request, $commentableType, $commentableId)
    {
        $commentable = $this->getCommentableEntity($commentableType, $commentableId);

        $comment = $this->commentRepository->storeComment($request->validated(), $commentable);

        return new CommentResource($comment);
    }

    /**
     * Get comments for a specific commentable entity.
     */
    public function index($commentableType, $commentableId)
    {
        $commentable = $this->getCommentableEntity($commentableType, $commentableId);

        $cacheKey = "comments_{$commentableType}_{$commentableId}";
        $ttl = now()->addMinutes(env('COMMENTS_CACHE_TTL', 10));

        $comments = Cache::remember($cacheKey, $ttl, function () use ($commentable) {
            return $this->commentRepository->getCommentsForCommentable($commentable);
        });

        return CommentResource::collection($comments);
    }

    /**
     * Get the commentable entity based on the type.
     */
    private function getCommentableEntity($type, $id)
    {
        if ($type === 'post') {
            return Post::findOrFail($id);
        }

        if ($type === 'user') {
            return User::findOrFail($id);
        }

        abort(404, 'Commentable entity not found.');
    }
}

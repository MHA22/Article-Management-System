<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Tag extends Model
{
    use HasFactory;

    protected $table = 'tags';
    protected $fillable = ['name'];

    public function posts()
    {
        return $this->belongsToMany(Post::class);
    }

    public static function getTagsMap()
    {
        return self::all()->keyBy('id')->map(function ($tag) {
            return $tag->name;
        });
    }

    public function getTagsWithCounts()
    {
        $tagsMap = $this->getTagsMap();
        $tagCounts = $this->getTagPostCounts();

        return collect($tagsMap)->map(function ($tagName, $tagId) use ($tagCounts) {
            return [
                'id' => $tagId,
                'name' => $tagName,
                'post_count' => $tagCounts[$tagId]->post_count ?? 0,
            ];
        });
    }

    public function getTagPostCounts()
    {
        return DB::table('post_tag')
            ->select('tag_id', DB::raw('COUNT(post_id) as post_count'))
            ->groupBy('tag_id')
            ->get()
            ->keyBy('tag_id');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    use HasFactory;

    protected $fillable = ['commentable_id', 'commentable_type', 'content'];

    public function commentable()
    {
        return $this->morphTo();
    }

    public function setCommentable($commentable)
    {
        $this->commentable = $commentable;
    }

    public function getCommentable()
    {
        return $this->commentable;
    }
}

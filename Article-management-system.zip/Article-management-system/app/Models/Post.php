<?php

namespace App\Models;

use App\Events\PostUpdated;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    use HasFactory;

    protected $fillable = ['user_id', 'title', 'content'];

    protected $dispatchesEvents = [
        'created' => PostUpdated::class,
        'updated' => PostUpdated::class,
        'deleted' => PostUpdated::class,
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function tags()
    {
        return $this->belongsToMany(Tag::class);
    }

    public function comments()
    {
        return $this->morphMany(Comment::class, 'commentable');
    }

    public function postTag()
    {
        return $this->belongsToMany(Tag::class, 'post_tag', 'post_id', 'tag_id')
            ->withTimestamps();
    }


    //
    public function getPostsWithTags()
    {
        $tagsMap = $this->getTagsMap();

        return Post::with('tags')->get()->map(function ($post) use ($tagsMap) {
            $postTags = $post->tags->pluck('id')->map(function ($tagId) use ($tagsMap) {
                return $tagsMap[$tagId];
            });

            return [
                'id' => $post->id,
                'title' => $post->title,
                'tags' => $postTags,
            ];
        });
    }

}

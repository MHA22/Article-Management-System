<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;

class CreateRepository extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'make:repository {name}';

    protected $description = 'Create a new Repository class';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $name = $this->argument('name');

        $folder = app_path('Repositories');
        $fileName = Str::studly($name) . 'Repository.php';
        $filePath = $folder . DIRECTORY_SEPARATOR . $fileName;

        if (!File::exists($folder)) {
            File::makeDirectory($folder, 0755, true);
        }

        if (File::exists($filePath)) {
            $this->error('Repository already exists!');
            return;
        }

        $stub = file_get_contents(base_path('app/Stubs/repository.stub'));

        $stub = str_replace('{{class}}', Str::studly($name), $stub);

        File::put($filePath, $stub);

        $this->info("Repository {$fileName} created successfully!");
    }
}

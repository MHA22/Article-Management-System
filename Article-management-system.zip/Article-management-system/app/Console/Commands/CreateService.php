<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;

class CreateService extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'make:service {name}';

    protected $description = 'Create a new Service class';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $name = $this->argument('name');

        $folder = app_path('Services');
        $fileName = Str::studly($name) . 'Service.php';
        $filePath = $folder . DIRECTORY_SEPARATOR . $fileName;

        if (!File::exists($folder)) {
            File::makeDirectory($folder, 0755, true);
        }

        if (File::exists($filePath)) {
            $this->error('Service already exists!');
            return;
        }

        $stub = file_get_contents(base_path('app/Stubs/service.stub'));

        $stub = str_replace('{{class}}', Str::studly($name), $stub);

        File::put($filePath, $stub);

        $this->info("Service {$fileName} created successfully!");
    }
}

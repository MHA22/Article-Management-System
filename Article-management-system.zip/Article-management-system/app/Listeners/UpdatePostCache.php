<?php

namespace App\Listeners;

use App\Models\Post;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Cache;

class UpdatePostCache
{
    /**
     * Create the event listener.
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     */
    public function handle(object $event): void
    {
        Cache::forget('posts_with_details');

        $ttl = now()->addMinutes(env('POST_CACHE_TTL', 10));
        Cache::remember('posts_with_details', $ttl, function () {
            return Post::with('user', 'comments', 'tags')->get();
        });
    }
}

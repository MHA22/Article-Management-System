<?php

namespace Tests\Feature;

use App\Models\Post;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class CommentPolymorphicFeatureTest extends TestCase
{
    use RefreshDatabase;

    /** @test */
    public function a_post_can_have_comments()
    {
        $post = Post::factory()->create();

        $post->comments()->create(['content' => 'نظر اول']);
        $post->comments()->create(['content' => 'نظر دوم']);

        $this->assertCount(2, $post->comments);

        $this->assertEquals('نظر اول', $post->comments[0]->content);
        $this->assertEquals('نظر دوم', $post->comments[1]->content);
    }

    /** @test */
    public function a_user_can_have_comments()
    {
        $user = User::factory()->create();

        $user->comments()->create(['content' => 'نظر کاربر']);

        $this->assertCount(1, $user->comments);

        $this->assertEquals('نظر کاربر', $user->comments[0]->content);
    }

    /** @test */
    public function a_comment_can_retrieve_its_commentable_entity()
    {
        $post = Post::factory()->create();
        $comment = $post->comments()->create(['content' => 'نظر مرتبط با مقاله']);

        $this->assertInstanceOf(Post::class, $comment->commentable);
        $this->assertEquals($post->id, $comment->commentable->id);

        $user = User::factory()->create();
        $comment = $user->comments()->create(['content' => 'نظر مرتبط با کاربر']);

        $this->assertInstanceOf(User::class, $comment->commentable);
        $this->assertEquals($user->id, $comment->commentable->id);
    }
}

<?php

namespace Tests\Unit;

use App\Models\Comment;
use App\Models\Post;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use PHPUnit\Framework\TestCase;

class CommentPolymorphicUnitTest extends TestCase
{
    public function test_a_comment_can_belong_to_a_post_using_mocking()
    {
        $postMock = $this->createMock(Post::class);

        $comment = new Comment();
        $comment->setCommentable($postMock);

        $this->assertSame($postMock, $comment->getCommentable());
    }


    public function test_a_comment_can_belong_to_a_user_using_mocking()
    {

        $userMock = $this->createMock(User::class);


        $comment = new Comment();
        $comment->setCommentable($userMock);

        $this->assertSame($userMock, $comment->getCommentable());
    }
}
